function filtrareSortare(array, filters, sortKey = "pret", order = "asc") {
  let filteredData = array.filter((item) => {
    return Object.keys(filters).every((key) => {
      const filterValue = filters[key];
      if (!filterValue) return true;
      if (key === "oras" && typeof item[key] === "string") {
        return item[key].toLowerCase().includes(filterValue.toLowerCase());
      }
      if (key === "pretMin" && item[key] < filterValue) return false;
      if (key === "pretMax" && item[key] > filterValue) return false;
      if (key === "metriMin" && item[key] < filterValue) return false;
      if (key === "metriMax" && item[key] > filterValue) return false;

      return item[key] >= filterValue;
    });
  });
console.log(filteredData, array)
  return filteredData.sort((a, b) => {
    let valA = a[sortKey];
    let valB = b[sortKey];
    if (typeof valA === "string" && typeof valB === "string") {
      return order === "asc"
        ? valA.localeCompare(valB)
        : valB.localeCompare(valA);
    }

    return order === "asc" ? valA - valB : valB - valA;
  });
}

export { filtrareSortare };

export function getStoredAnnouncements() {
  const announcements = readFromLS("announcements");
  return announcements ? Object.values(announcements).flat() : [];
}
